<?php
$handler = 'Controller:home';
require_once('./app.inc.php');
