<?php
$handler = 'Controller:audiences';
require_once('./app.inc.php');
