<?php
$handler = 'Controller:proxy';
require_once('./app.inc.php');
