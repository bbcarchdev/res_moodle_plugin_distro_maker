<?php
$handler = 'Controller:minimal';
require_once('./app.inc.php');
