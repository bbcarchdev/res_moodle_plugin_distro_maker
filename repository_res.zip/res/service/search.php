<?php
$handler = 'Controller:search';
require_once('./app.inc.php');
