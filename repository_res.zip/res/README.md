# RES Moodle plugin

Short description

Longer description - Explain what RES is

Architecture behind the plugin (external file chooser)

Dependency on plugin service

Copyright declaration

See https://github.com/moodle/moodle/tree/master/repository/wikimedia for the
official Wikimedia plugin, which this is vaguely based on.

Tested with MySQL (see res_moodle_stack project).

???needs testing with Postgres
